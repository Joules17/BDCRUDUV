const { Pool } = require('pg');
const Router = require('express-promise-router');
const { response } = require('express');

const pool = new Pool({
  user: 'gjfcuoiubknezz',
  host: 'ec2-54-158-222-248.compute-1.amazonaws.com',
  database: 'd4mbivmgeh7ajk',
  password: 'a7db9b4aef0d2d1df2f81ed28612ede54339f915917a76fc2bae34ac8fc9583d',
  port: 5432,
  connecionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

const router = new Router();
// export our router to be mounted by the parent application
module.exports = router;

router.get('/consultatotalpacientes', async (req, res) => {
  //const { id } = req.params
  const { rows } = await pool.query('SELECT * FROM pacientes');
  res.send(rows);
});

router.post('/insertarpacientes', async (req, res) => {
  const { nombre, apellido, numid } = req.body;
  await pool.query(
    `INSERT INTO pacientes(nombre, apellido, numid) VALUES('${nombre}','${apellido}','${numid}')`
  );
  res.send('INSERTADO');
});

router.delete('/eliminarpacientes', async (req, res) => {
  const { numid } = req.body; 

  pool.query(
    `DELETE FROM pacientes WHERE numid = '${numid}'` , (error, results) => {

      if (error) {
        throw error
      }

      res.send(`Paciente eliminado con el numid: '${numid}'`)
    }
  )

});

router.post('/actualizarpacientes', async (req, res) => {
  const {numid, nombre, apellido} = req.body

  pool.query(
    `UPDATE pacientes SET nombre = $2, apellido = $3 WHERE numid = $1`,
     [numid, nombre, apellido], 
    (error, results) => {
      if (error)
      {
        throw error
      }

      res.send(`Paciente actualizado con el numid: ${numid}`)
    }
    
    )


}); 


